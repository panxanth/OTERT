﻿//Copyright (C) Microsoft Corporation.  All rights reserved.

// Hello2.cs
using System;

public class Hello2
{
   public static void Main()
   {
      Console.WriteLine("Hello, World!");
   }
}


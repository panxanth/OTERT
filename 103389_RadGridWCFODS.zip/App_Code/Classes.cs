﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace RadGrid.Example
{
    public class Order
    {
        public Order()
        {

        }

        public Order(int OrderID, int EmployeeID, string CustomerID)
        {
            this.OrderID = OrderID;
            this.EmployeeID = EmployeeID;
            this.CustomerID = CustomerID;
        }

        public int OrderID
        { get; set; }

        public int EmployeeID
        { get; set; }

        public string CustomerID
        { get; set; }

    }

    public class Employee
    {
        public Employee()
        {

        }

        public Employee(int EmployeeID, string LastName)
        {            
            this.EmployeeID = EmployeeID;
            this.LastName = LastName;
        }

        public int EmployeeID
        { get; set; }

        public string LastName
        { get; set; }

    }


    public class Orders
    {
        public List<Order> SelectData()
        {
            List<Order> orders = new List<Order>();
            orders.Add(new Order { OrderID = 10248, EmployeeID = 5, CustomerID = "VINET" });
            orders.Add(new Order { OrderID = 10249, EmployeeID = 6, CustomerID = "TOMSP" });

            return orders;
        }

        public int CountSelectedData()
        {
            return 2;
        }

        public void UpdateRecord(int EmployeeID, int OrderID, string CustomerID)
        {
 
        }
    }

    public class Employees
    {
        public List<Employee> SelectData()
        {
            List<Employee>  employees = new List<Employee>();
            employees.Add(new Employee { EmployeeID = 5, LastName = "Buchanan" });
            employees.Add(new Employee { EmployeeID = 6, LastName = "Suyama" });

            return employees;
        }

        public int CountSelectedData()
        {
            return 2;
        }

    }
}

